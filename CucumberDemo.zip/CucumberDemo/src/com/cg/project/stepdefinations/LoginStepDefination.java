package com.cg.project.stepdefinations;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.pagebeans.LoginPage;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefination {
	private WebDriver driver;
	private LoginPage loginPage;
	
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\\\software bachup\\\\chromedriver.exe");
	}

	@Given("^User is on the log-in page of app\\.$")
	public void user_is_on_the_log_in_page_of_app() throws Throwable {
		driver = new ChromeDriver();
		driver.get("https://github.com/login");
		
		loginPage = PageFactory.initElements(driver, LoginPage.class);
	}

	@When("^User Enter Invalid username or password\\.$")
	public void user_Enter_Invalid_username_or_password() throws Throwable {
		loginPage.setUsername("jasmeetgaba");
		loginPage.setPassword("90501");
		loginPage.clickSignIn();
	}

	@Then("^Invalid username/password message should generate\\.$")
	public void invalid_username_password_message_should_generate() throws Throwable {
		String expectedErrorMessage = "Incorrect Username or Password";
		Assert.assertEquals(expectedErrorMessage, loginPage.getActualErrorMessage());
	}

	@When("^User Enter Valid username or password\\.$")
	public void user_Enter_Valid_username_or_password() throws Throwable {
		loginPage.setUsername("jasmeetgaba");
		loginPage.setPassword("J@smeet1");
		loginPage.clickSignIn();
	}

	@Then("^User should Successully Signin on his account\\.$")
	public void user_should_Successully_Signin_on_his_account() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle = "jasmeetgaba";
		Assert.assertEquals(expectedTitle, actualTitle);
	}
	
	@After
	public void tearDownStepEnv() {
		driver.close();
	}
}
