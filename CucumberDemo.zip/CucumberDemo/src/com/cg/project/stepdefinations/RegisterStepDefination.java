package com.cg.project.stepdefinations;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegisterStepDefination {
	@Given("^User is on the Registration page of app\\.$")
	public void user_is_on_the_Registration_page_of_app() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User Enter His/Her Details\\.$")
	public void user_Enter_His_Her_Details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^If all details are correct and valid then account will be opened\\.$")
	public void if_all_details_are_correct_and_valid_then_account_will_be_opened() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
}
